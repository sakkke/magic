# Magic Mod

魔術関連Mod。

## 機能

### ブロック

- PoisonPumpkin: 紫色のカボチャ 特殊効果なし

### ツール

- InfinityRod: 攻撃力1000の棒
- RainRod: 右クリックすると天気を雨に変更
- SunRod: 右クリックすると天気を晴れに変更
- ThunderRod: 右クリックすると天気を雷雨に変更
